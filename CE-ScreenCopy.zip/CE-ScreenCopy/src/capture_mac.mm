#import <Foundation/Foundation.h>
#import <ScreenCaptureKit/ScreenCaptureKit.h>
#import <CoreMedia/CoreMedia.h>
#import <CoreVideo/CoreVideo.h>
#include "capture_mac.h"
#include "protocol.h"
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <string.h>
#include <string>

@interface C2KStreamOutput : NSObject <SCStreamOutput, SCStreamDelegate>
@property (nonatomic, assign) void* owner;
@end

struct MacCapture::Impl {
    SCStream* stream = nil;
    C2KStreamOutput* output = nil;
    dispatch_queue_t queue = nil;
    std::mutex m;
    std::condition_variable cv;
    uint8_t frame[CALC_WIDTH * CALC_HEIGHT * 4];
    bool hasFrame = false;
    bool fresh = false;
    std::string err;

    void onFrame(CVPixelBufferRef pb) {
        if (CVPixelBufferLockBaseAddress(pb, kCVPixelBufferLock_ReadOnly) != kCVReturnSuccess) return;
        size_t w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb);
        size_t stride = CVPixelBufferGetBytesPerRow(pb);
        const uint8_t* src = (const uint8_t*)CVPixelBufferGetBaseAddress(pb);
        if (src && w >= CALC_WIDTH && h >= CALC_HEIGHT) {
            std::lock_guard<std::mutex> lk(m);
            for (int y = 0; y < CALC_HEIGHT; y++)
                memcpy(frame + (size_t)y * CALC_WIDTH * 4, src + (size_t)y * stride, CALC_WIDTH * 4);
            hasFrame = true;
            fresh = true;
            cv.notify_all();
        }
        CVPixelBufferUnlockBaseAddress(pb, kCVPixelBufferLock_ReadOnly);
    }
};

@implementation C2KStreamOutput
- (void)stream:(SCStream*)stream didOutputSampleBuffer:(CMSampleBufferRef)sb ofType:(SCStreamOutputType)type {
    if (type != SCStreamOutputTypeScreen || !CMSampleBufferIsValid(sb)) return;
    NSArray* atts = (__bridge NSArray*)CMSampleBufferGetSampleAttachmentsArray(sb, false);
    if (atts.count) {
        NSNumber* st = ((NSDictionary*)atts[0])[SCStreamFrameInfoStatus];
        if (st && st.integerValue != SCFrameStatusComplete) return;
    }
    CVPixelBufferRef pb = CMSampleBufferGetImageBuffer(sb);
    if (!pb) return;
    ((MacCapture::Impl*)self.owner)->onFrame(pb);
}
- (void)stream:(SCStream*)stream didStopWithError:(NSError*)error {
    MacCapture::Impl* i = (MacCapture::Impl*)self.owner;
    std::lock_guard<std::mutex> lk(i->m);
    i->err = error.localizedDescription.UTF8String ?: "stream stopped";
    i->hasFrame = false;
}
@end

MacCapture::MacCapture() : impl(new Impl()) {}
MacCapture::~MacCapture() { stop(); delete impl; }

const char* MacCapture::lastError() const { return impl->err.c_str(); }

bool MacCapture::start() {
    if (impl->stream) return true;
    impl->err.clear();
    impl->hasFrame = false;

    __block SCShareableContent* content = nil;
    __block NSError* contentErr = nil;
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    [SCShareableContent getShareableContentWithCompletionHandler:^(SCShareableContent* c, NSError* e) {
        content = c; contentErr = e;
        dispatch_semaphore_signal(sem);
    }];
    if (dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC)) != 0 ||
        !content || content.displays.count == 0) {
        impl->err = contentErr ? contentErr.localizedDescription.UTF8String
                               : "No display found (is Screen Recording permission granted?)";
        return false;
    }

    SCDisplay* display = content.displays.firstObject;
    SCContentFilter* filter = [[SCContentFilter alloc] initWithDisplay:display excludingWindows:@[]];
    SCStreamConfiguration* cfg = [[SCStreamConfiguration alloc] init];
    cfg.width = CALC_WIDTH;
    cfg.height = CALC_HEIGHT;
    cfg.minimumFrameInterval = CMTimeMake(1, 30);
    cfg.pixelFormat = kCVPixelFormatType_32BGRA;
    cfg.showsCursor = YES;
    cfg.queueDepth = 3;

    impl->output = [[C2KStreamOutput alloc] init];
    impl->output.owner = impl;
    impl->queue = dispatch_queue_create("cescreencopy.capture", DISPATCH_QUEUE_SERIAL);
    impl->stream = [[SCStream alloc] initWithFilter:filter configuration:cfg delegate:impl->output];

    NSError* addErr = nil;
    if (![impl->stream addStreamOutput:impl->output type:SCStreamOutputTypeScreen
                    sampleHandlerQueue:impl->queue error:&addErr]) {
        impl->err = addErr.localizedDescription.UTF8String ?: "addStreamOutput failed";
        impl->stream = nil;
        return false;
    }

    __block NSError* startErr = nil;
    dispatch_semaphore_t sem2 = dispatch_semaphore_create(0);
    [impl->stream startCaptureWithCompletionHandler:^(NSError* e) {
        startErr = e;
        dispatch_semaphore_signal(sem2);
    }];
    if (dispatch_semaphore_wait(sem2, dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC)) != 0 || startErr) {
        impl->err = startErr ? startErr.localizedDescription.UTF8String : "capture start timed out";
        impl->stream = nil;
        return false;
    }
    return true;
}

void MacCapture::stop() {
    if (!impl->stream) return;
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    [impl->stream stopCaptureWithCompletionHandler:^(NSError* e) { dispatch_semaphore_signal(sem); }];
    dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC));
    impl->stream = nil;
    impl->output = nil;
}

bool MacCapture::captureNext(uint8_t* dest, int waitMs) {
    std::unique_lock<std::mutex> lk(impl->m);
    if (!impl->fresh)
        impl->cv.wait_for(lk, std::chrono::milliseconds(waitMs), [&] { return impl->fresh; });
    if (!impl->hasFrame) return false;
    memcpy(dest, impl->frame, sizeof(impl->frame));
    impl->fresh = false;
    return true;
}
