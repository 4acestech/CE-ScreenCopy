// Ported from Calc2KeyCE.Fast (MIT, (c) 2023 David Malenke): Windows desktop-duplication
// replaced by ScreenCaptureKit (capture_mac.mm); QueryPerformanceCounter -> std::chrono.
#include "sender.h"
#include "protocol.h"
#include "leptonica/allheaders.h"
#include "compression.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <chrono>
#include <thread>
#ifndef C2K_NO_CAPTURE
#include "capture_mac.h"
#endif

constexpr double COLOR_MULT = 31 / 255.0;
constexpr int STATS_BUF_SIZE = 64;

bool running = false;
char captureError[256] = { 0 };

static uint16_t ConvertColor(uint32_t color)
{
    return (uint16_t)(((int)round((color & 0xFF) * COLOR_MULT) << 10)
                    + ((int)round(((color >> 8) & 0xFF) * COLOR_MULT) << 5)
                    + ((int)round(((color >> 16) & 0xFF) * COLOR_MULT) << 0));
}

static void pixFunc(PIX* pix, uint8_t* sendBuf)
{
    PIX* qPic = pixOctreeColorQuant(pix, 240, 0);
    PIX* rPic = pixRotate90(qPic, 1);

    uint32_t* picData = pixGetData(rPic);
    uint32_t* colors = *(uint32_t**)pixGetColormap(rPic);

    for (int i = 0; i < 256; i++)
        *(uint16_t*)(sendBuf + 2 * i) = ConvertColor(colors[i]);

    for (size_t i = 0; i < CALC_WIDTH * CALC_HEIGHT / 4; i++)
        *(uint32_t*)(sendBuf + 512 + 4 * i) = ((picData[i] & 0xFF) << 24) | (((picData[i] >> 8) & 0xFF) << 16)
                                            | (((picData[i] >> 16) & 0xFF) << 8) | ((picData[i] >> 24) & 0xFF);

    pixDestroy(&qPic);
    pixDestroy(&rPic);
}

int buildPacket(struct Pix* pix, uint8_t* sendBuf)
{
    pixFunc(pix, sendBuf);

    int outSize = 0;
    int sendLen = PACKET_BUF_LEN;
    // ZX0 timeout is in clock() ticks: upstream's "25" meant 25 ms on Windows (CLOCKS_PER_SEC==1000).
    uint8_t* compBuf = compress(optimize(sendBuf + 512, PACKET_BUF_LEN - 512, 0, 1,
                                         (long)(25 * (CLOCKS_PER_SEC / 1000))),
                                sendBuf + 512, PACKET_BUF_LEN - 512, 0, 0, 1, &outSize);
    if (compBuf != NULL)
    {
        if (outSize <= 60032)
        {
            sendLen = outSize + 512;
            if (sendLen % 64 != 0) sendLen += 64 - (sendLen % 64);
            memcpy(sendBuf + 512, compBuf, outSize);
            memset(sendBuf + outSize + 512, 0, (size_t)sendLen - outSize - 512);
        }
        free(compBuf);
    }
    return sendLen;
}

static float timeBuf[STATS_BUF_SIZE] = { 0 };
static int curBufIdx = 0;

float getFrameTime(void*, int idx) { return timeBuf[(curBufIdx + idx) % STATS_BUF_SIZE]; }

#ifndef C2K_NO_CAPTURE
static bool sendAll(libusb_device_handle* h, uint8_t* buf, int len)
{
    for (int i = 0; i < len; i += 64)
    {
        int sent = 0;
        int rc = libusb_bulk_transfer(h, EP_OUT, buf + i, 64, &sent, 0);
        if (rc != 0 || sent != 64) return false;
    }
    return true;
}

void sendThread(libusb_device_handle* devHandle, volatile sig_atomic_t* stop)
{
    using clk = std::chrono::steady_clock;
    running = true;
    captureError[0] = 0;

    MacCapture cap;
    if (!cap.start())
    {
        snprintf(captureError, sizeof captureError, "%s", cap.lastError());
        fprintf(stderr, "Capture failed: %s\n", captureError);
        *stop = 1;
        running = false;
        return;
    }

    uint8_t* sendBuf = (uint8_t*)malloc(PACKET_BUF_LEN);
    uint8_t* bits = (uint8_t*)malloc(CALC_WIDTH * CALC_HEIGHT * 4 + 1);
    if (!sendBuf || !bits) { *stop = 1; running = false; return; }
    PIX* picture = pixCreateHeader(CALC_WIDTH, CALC_HEIGHT, 32);
    pixSetData(picture, (uint32_t*)bits);

    uint8_t sizeBuf[64];
    int noFrames = 0;

    while (!*stop)
    {
        if (!cap.captureNext(bits + 1))
        {
            if (++noFrames == 100) // ~3s
            {
                snprintf(captureError, sizeof captureError, "%s",
                         cap.lastError()[0] ? cap.lastError() : "No frames from ScreenCaptureKit (check Screen Recording permission)");
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            continue;
        }
        noFrames = 0;
        captureError[0] = 0;

        auto t1 = clk::now();
        int sendLen = buildPacket(picture, sendBuf);

        memset(sizeBuf, 0, sizeof sizeBuf);
        memcpy(sizeBuf, &sendLen, sizeof(int));

        if (!sendAll(devHandle, sizeBuf, 64) || !sendAll(devHandle, sendBuf, sendLen))
        {
            fprintf(stderr, "Failed to send. Exiting...\n");
            *stop = 1;
            break;
        }

        float t = std::chrono::duration<float, std::milli>(clk::now() - t1).count();
        timeBuf[curBufIdx++] = t;
        if (curBufIdx == STATS_BUF_SIZE) curBufIdx = 0;
    }

    int endLen = -1;
    memset(sizeBuf, 0, sizeof sizeBuf);
    memcpy(sizeBuf, &endLen, sizeof(int));
    int sent = 0;
    libusb_bulk_transfer(devHandle, EP_OUT, sizeBuf, 64, &sent, 500);

    pixDestroy(&picture);   // frees bits
    free(sendBuf);
    cap.stop();
    running = false;
}
#endif
