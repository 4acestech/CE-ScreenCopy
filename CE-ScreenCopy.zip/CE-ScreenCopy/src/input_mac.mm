#import <ApplicationServices/ApplicationServices.h>
#include <math.h>
#include "protocol.h"

static bool leftHeld = false, rightHeld = false;

static CGPoint currentPos()
{
    CGEventRef e = CGEventCreate(NULL);
    CGPoint p = CGEventGetLocation(e);
    CFRelease(e);
    return p;
}

void inputKey(int code, bool down)
{
    if (code < 0) return;
    CGEventRef e = CGEventCreateKeyboardEvent(NULL, (CGKeyCode)code, down);
    if (!e) return;
    CGEventPost(kCGHIDEventTap, e);
    CFRelease(e);
}

void inputMouseButton(uint32_t mb, bool down)
{
    bool left = (mb == MB_LEFT);
    if (!left && mb != MB_RIGHT) return;
    CGEventType type = left ? (down ? kCGEventLeftMouseDown : kCGEventLeftMouseUp)
                            : (down ? kCGEventRightMouseDown : kCGEventRightMouseUp);
    CGEventRef e = CGEventCreateMouseEvent(NULL, type, currentPos(), left ? kCGMouseButtonLeft : kCGMouseButtonRight);
    if (!e) return;
    CGEventPost(kCGHIDEventTap, e);
    CFRelease(e);
    (left ? leftHeld : rightHeld) = down;
}

void inputMouseMove(int dx, int dy)
{
    CGPoint p = currentPos();
    CGPoint np = CGPointMake(p.x + dx, p.y + dy);

    CGDirectDisplayID ids[16]; uint32_t n = 0;
    if (CGGetActiveDisplayList(16, ids, &n) == kCGErrorSuccess && n > 0)
    {
        CGRect u = CGDisplayBounds(ids[0]);
        for (uint32_t i = 1; i < n; i++) u = CGRectUnion(u, CGDisplayBounds(ids[i]));
        np.x = fmin(fmax(np.x, u.origin.x), u.origin.x + u.size.width - 1);
        np.y = fmin(fmax(np.y, u.origin.y), u.origin.y + u.size.height - 1);
    }

    CGEventType type = leftHeld ? kCGEventLeftMouseDragged : rightHeld ? kCGEventRightMouseDragged : kCGEventMouseMoved;
    CGMouseButton btn = rightHeld && !leftHeld ? kCGMouseButtonRight : kCGMouseButtonLeft;
    CGEventRef e = CGEventCreateMouseEvent(NULL, type, np, btn);
    if (!e) return;
    CGEventSetIntegerValueField(e, kCGMouseEventDeltaX, dx);
    CGEventSetIntegerValueField(e, kCGMouseEventDeltaY, dy);
    CGEventPost(kCGHIDEventTap, e);
    CFRelease(e);
}
