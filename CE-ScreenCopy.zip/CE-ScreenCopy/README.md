# CE-ScreenCopy for macOS
Made by @4acestech

Mac port of Calc2KeyCE.Fast (https://github.com/dnmalenke/Calc2KeyCE, MIT). Same calculator-side
program and USB protocol, so **your existing CALC2KEY.8xp + usbdrvce on the calc work unchanged**.

- Screen mirroring: ScreenCaptureKit -> 320x240 -> same palette/ZX0 packing as the Windows build
- Calc keys -> keyboard / mouse via CGEvent (bind, save/load bindings, mouse speed)
- Simple AppKit window: connection status, permissions, fps, binding table

## Build (on the Mac)
    cd Calc2KeyCE-mac && ./build.sh
Installs libusb/leptonica/dylibbundler via Homebrew, builds `CE-ScreenCopy.app`, bundles the libs, ad-hoc signs it.

## Use
1. Calc: run `CALC2KEY` (needs usbdrvce + CE C libs on the calc, same as the Windows version). Back up RAM first. [ON] exits.
2. Plug in the calc, open the app (first time: right-click > Open).
3. Click **Grant Permissions…**:
   - Screen Recording (mirroring)
   - Accessibility (key/mouse binds)
   Then quit and reopen the app once after granting.
4. Status should read "Connected to calculator."

No Zadig / driver install is needed on macOS; libusb talks to it directly.

## Tests
`test/test_core.cpp` covers report decoding, bindings and frame packing (built on Linux).
The ScreenCaptureKit / CGEvent / AppKit parts only compile on macOS.
