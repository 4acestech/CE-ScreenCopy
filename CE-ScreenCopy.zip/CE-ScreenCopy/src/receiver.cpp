// Ported from Calc2KeyCE.Fast (MIT, (c) 2023 David Malenke). Windows SendInput replaced by an
// input backend (input_mac.mm: CGEvent). Report decoding is portable so it can be unit-tested.
#include "receiver.h"
#include "protocol.h"
#include "keypad.h"
#include <stdio.h>
#include <string.h>

uint32_t keyBindings[128] = { 0 };
int      mouseSpeed = 10;
uint8_t  lastCalcKeyUp = 0xFF;

static uint8_t prevRec[7] = { 0 };
static uint8_t moveState = 0;   // bit0 up, bit1 down, bit2 left, bit3 right

static bool keyFor(int i, uint8_t& idx, uint8_t& bit)
{
    idx = (i >> 4) & 7;
    int shift = i & 0xF;
    if (idx >= 7 || shift > 7) return false;
    bit = (uint8_t)(1u << shift);
    return true;
}

void processReport(const uint8_t* rec)
{
    for (int i = 0; i < 128; i++)
    {
        uint32_t b = keyBindings[i];
        uint8_t idx, bit;
        if (!b || !keyFor(i, idx, bit)) continue;

        bool pressed = rec[idx] & bit;
        bool was = prevRec[idx] & bit;
        if (pressed == was) continue;

        if (b & BIND_KEYBOARD)
        {
            inputKey(KB_DECODE(b), pressed);
        }
        else
        {
            uint32_t mType = b & 0xFF;
            if (mType == MB_MOVE)
            {
                uint8_t dir = (b >> 8) & 3;
                if (pressed) moveState |= (1 << dir);
                else         moveState &= ~(1 << dir);
            }
            else
            {
                inputMouseButton(mType, pressed);
            }
        }
    }

    // remember the most recently released calc key (used by the "Bind Key" UI)
    for (int i = 0; i < 7; i++)
    {
        uint8_t released = prevRec[i] & (uint8_t)~rec[i];
        for (int s = 0; s < 8 && released; s++)
            if (released & (1 << s)) { lastCalcKeyUp = (uint8_t)((i << 4) | s); break; }
    }

    memcpy(prevRec, rec, 7);
}

void applyMouseMotion()
{
    if (!moveState) return;
    int dy = (moveState & 1) * -mouseSpeed + ((moveState >> 1) & 1) * mouseSpeed;
    int dx = ((moveState >> 2) & 1) * -mouseSpeed + ((moveState >> 3) & 1) * mouseSpeed;
    inputMouseMove(dx, dy);
}

// Release anything still "held" (calc unplugged / program exited mid key-press).
void resetInputState()
{
    for (int i = 0; i < 128; i++)
    {
        uint32_t b = keyBindings[i];
        uint8_t idx, bit;
        if (!b || !keyFor(i, idx, bit) || !(prevRec[idx] & bit)) continue;
        if (b & BIND_KEYBOARD) inputKey(KB_DECODE(b), false);
        else if ((b & 0xFF) != MB_MOVE) inputMouseButton(b & 0xFF, false);
    }
    memset(prevRec, 0, sizeof prevRec);
    moveState = 0;
}

void receiveThread(libusb_device_handle* devHandle, volatile sig_atomic_t* stop)
{
    uint8_t rec[7];
    int errStreak = 0;

    while (!*stop)
    {
        int received = 0;
        memset(rec, 0, sizeof rec);
        int rc = libusb_bulk_transfer(devHandle, EP_IN, rec, 7, &received, 10);

        if (rc == LIBUSB_ERROR_NO_DEVICE) { *stop = 1; break; }
        if (rc != 0 && rc != LIBUSB_ERROR_TIMEOUT && rc != LIBUSB_ERROR_OVERFLOW)
        {
            if (++errStreak >= 50) { *stop = 1; break; }
        }
        else errStreak = 0;

        if (received > 0) processReport(rec);
        applyMouseMotion();
    }

    resetInputState();
}
