// CE-ScreenCopy (made by @4acestech) - simple AppKit UI. Port of Calc2KeyCE.Fast (MIT, (c) 2023 David Malenke).
#import <Cocoa/Cocoa.h>
#include <atomic>
#include <thread>
#include <chrono>
#include <signal.h>
#include <stdio.h>
#include "protocol.h"
#include "sender.h"
#include "receiver.h"
#include "keypad.h"

// ---------- shared state ----------
static std::atomic<int>  calcState{0};   // 0 none, 1 calc in OS mode, 2 permission/open error, 3 connected
static std::atomic<bool> done{false};
static volatile sig_atomic_t stopFlag = 0;
static std::atomic<bool> wantMirror{true};
static char usbOpenError[128] = {0};

static void runner()
{
    libusb_context* ctx = nullptr;
    if (libusb_init(&ctx) != 0) { calcState = 2; snprintf(usbOpenError, sizeof usbOpenError, "libusb init failed"); return; }

    while (!done)
    {
        libusb_device_handle* h = nullptr;
        while (!h && !done)
        {
            h = libusb_open_device_with_vid_pid(ctx, CALC_VID, CALC_PID_RUN);
            if (h) break;

            // is the calc plugged in but not running the CALC2KEY program?
            int st = 0;
            libusb_device** list = nullptr;
            ssize_t n = libusb_get_device_list(ctx, &list);
            for (ssize_t i = 0; i < n; i++) {
                libusb_device_descriptor d;
                if (libusb_get_device_descriptor(list[i], &d) == 0 && d.idVendor == CALC_VID) {
                    if (d.idProduct == CALC_PID_OS) st = 1;
                    if (d.idProduct == CALC_PID_RUN) st = 2;  // present but open() failed
                }
            }
            if (n >= 0) libusb_free_device_list(list, 1);
            calcState = st;
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }
        if (done) break;

        if (libusb_claim_interface(h, 0) != 0) {
            snprintf(usbOpenError, sizeof usbOpenError, "could not claim USB interface (another app using the calc?)");
            calcState = 2;
            libusb_close(h);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }
        calcState = 3;
        stopFlag = 0;

        std::thread tRecv(receiveThread, h, &stopFlag);
        std::thread tSend;
        if (wantMirror) tSend = std::thread(sendThread, h, &stopFlag);
        if (tSend.joinable()) tSend.join();
        else while (!stopFlag && !done) std::this_thread::sleep_for(std::chrono::milliseconds(50));
        stopFlag = 1;
        tRecv.join();

        libusb_release_interface(h, 0);
        libusb_close(h);
        calcState = 0;
        stopFlag = 0;
        if (!done) std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    libusb_exit(ctx);
}

// ---------- names ----------
static NSString* calcKeyName(uint8_t i)
{
    static const char* names[7][8] = {
        {"Graph","Trace","Zoom","Window","Y=","2nd","Mode","Del"},
        {"","Sto","Ln","Log","x²","x⁻¹","Math","Alpha"},
        {"0","1","4","7",",","Sin","Apps","X,T,θ,n"},
        {".","2","5","8","(","Cos","Prgm","Stat"},
        {"(-)","3","6","9",")","Tan","Vars",""},
        {"Enter","+","-","×","÷","^","Clear",""},
        {"Down","Left","Right","Up","","","",""},
    };
    int idx = (i >> 4) & 7, bit = i & 0xF;
    if (idx > 6 || bit > 7 || !names[idx][bit][0]) return [NSString stringWithFormat:@"Key %d", i];
    return [NSString stringWithUTF8String:names[idx][bit]];
}

static NSString* macKeyName(int code)
{
    static NSDictionary* t;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        t = @{@0:@"A",@11:@"B",@8:@"C",@2:@"D",@14:@"E",@3:@"F",@5:@"G",@4:@"H",@34:@"I",@38:@"J",@40:@"K",@37:@"L",
              @46:@"M",@45:@"N",@31:@"O",@35:@"P",@12:@"Q",@15:@"R",@1:@"S",@17:@"T",@32:@"U",@9:@"V",@13:@"W",@7:@"X",
              @16:@"Y",@6:@"Z",@29:@"0",@18:@"1",@19:@"2",@20:@"3",@21:@"4",@23:@"5",@22:@"6",@26:@"7",@28:@"8",@25:@"9",
              @36:@"Return",@48:@"Tab",@49:@"Space",@51:@"Delete",@53:@"Esc",@123:@"←",@124:@"→",@125:@"↓",@126:@"↑",
              @56:@"Shift",@59:@"Control",@58:@"Option",@55:@"Command",@27:@"-",@24:@"=",@33:@"[",@30:@"]",@41:@";",
              @39:@"'",@43:@",",@47:@".",@44:@"/",@42:@"\\",@50:@"`",
              @122:@"F1",@120:@"F2",@99:@"F3",@118:@"F4",@96:@"F5",@97:@"F6",@98:@"F7",@100:@"F8",@101:@"F9",@109:@"F10"};
    });
    return t[@(code)] ?: [NSString stringWithFormat:@"Key 0x%X", code];
}

static NSString* actionName(uint32_t b)
{
    if (b & BIND_KEYBOARD) return [@"Key: " stringByAppendingString:macKeyName(KB_DECODE(b))];
    uint32_t m = b & 0xFF;
    if (m == MB_MOVE) { NSArray* d = @[@"Mouse up", @"Mouse down", @"Mouse left", @"Mouse right"]; return d[(b >> 8) & 3]; }
    if (m == MB_LEFT) return @"Left click";
    if (m == MB_RIGHT) return @"Right click";
    return @"?";
}

// ---------- UI ----------
@interface AppDelegate : NSObject <NSApplicationDelegate, NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation AppDelegate {
    NSWindow* win;
    NSTextField* status; NSTextField* perms; NSTextField* fps; NSTextField* hint;
    NSButton* mirrorCheck;
    NSTableView* table;
    NSMutableArray<NSNumber*>* rows;
    NSPopUpButton* actionPop; NSButton* recordBtn; NSButton* bindBtn; NSButton* bindStart;
    NSTextField* bindLabel;
    NSSlider* speed;
    int bindingKey; bool binding; int recordedKey; id keyMonitor; bool recording;
    NSTimer* timer;
    std::thread* runThread;
}

- (NSTextField*)label:(NSString*)s frame:(NSRect)f {
    NSTextField* t = [NSTextField labelWithString:s]; t.frame = f; [win.contentView addSubview:t]; return t;
}
- (NSButton*)button:(NSString*)s frame:(NSRect)f action:(SEL)a {
    NSButton* b = [NSButton buttonWithTitle:s target:self action:a]; b.frame = f; [win.contentView addSubview:b]; return b;
}

- (void)applicationDidFinishLaunching:(NSNotification*)n {
    rows = [NSMutableArray array];
    bindingKey = -1; binding = false; recordedKey = -1; recording = false;

    win = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 560, 570)
            styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable
            backing:NSBackingStoreBuffered defer:NO];
    win.title = @"CE-ScreenCopy";
    [win center];

    NSTextField* title = [self label:@"CE-ScreenCopy" frame:NSMakeRect(20, 528, 360, 28)];
    title.font = [NSFont systemFontOfSize:22 weight:NSFontWeightBold];
    NSTextField* credit = [self label:@"Made by @4acestech" frame:NSMakeRect(20, 508, 360, 16)];
    credit.font = [NSFont systemFontOfSize:12 weight:NSFontWeightMedium];
    credit.textColor = NSColor.secondaryLabelColor;
    NSTextField* sub = [self label:@"TI-84 Plus CE screen mirror" frame:NSMakeRect(380, 532, 160, 16)];
    sub.alignment = NSTextAlignmentRight; sub.font = [NSFont systemFontOfSize:11]; sub.textColor = NSColor.secondaryLabelColor;

    status = [self label:@"Calculator not detected." frame:NSMakeRect(20, 485, 520, 20)];
    status.font = [NSFont boldSystemFontOfSize:14];
    perms  = [self label:@"" frame:NSMakeRect(20, 462, 520, 18)];
    perms.textColor = NSColor.secondaryLabelColor;
    fps    = [self label:@"" frame:NSMakeRect(20, 440, 520, 18)];

    mirrorCheck = [NSButton checkboxWithTitle:@"Mirror this Mac's screen to the calculator (applies on next connect)" target:self action:@selector(toggleMirror:)];
    mirrorCheck.frame = NSMakeRect(20, 412, 340, 22); mirrorCheck.state = NSControlStateValueOn;
    [win.contentView addSubview:mirrorCheck];
    [self button:@"Grant Permissions…" frame:NSMakeRect(380, 408, 160, 28) action:@selector(grantPerms:)];

    [self label:@"Mouse speed:" frame:NSMakeRect(20, 384, 90, 18)];
    speed = [NSSlider sliderWithValue:10 minValue:1 maxValue:40 target:self action:@selector(speedChanged:)];
    speed.frame = NSMakeRect(115, 382, 200, 22); [win.contentView addSubview:speed];

    // bind controls
    bindStart = [self button:@"Bind Key…" frame:NSMakeRect(20, 345, 100, 28) action:@selector(startBind:)];
    bindLabel = [self label:@"" frame:NSMakeRect(130, 350, 410, 18)];
    actionPop = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(20, 312, 160, 26) pullsDown:NO];
    [actionPop addItemsWithTitles:@[@"Keyboard key", @"Mouse up", @"Mouse down", @"Mouse left", @"Mouse right", @"Left click", @"Right click"]];
    [win.contentView addSubview:actionPop];
    recordBtn = [self button:@"Record key" frame:NSMakeRect(190, 312, 120, 28) action:@selector(recordKey:)];
    bindBtn = [self button:@"Save binding" frame:NSMakeRect(320, 312, 110, 28) action:@selector(commitBind:)];
    [self button:@"Cancel" frame:NSMakeRect(435, 312, 80, 28) action:@selector(cancelBind:)];
    [self setBindControlsHidden:YES];

    NSScrollView* sv = [[NSScrollView alloc] initWithFrame:NSMakeRect(20, 70, 520, 230)];
    sv.hasVerticalScroller = YES; sv.borderType = NSBezelBorder;
    table = [[NSTableView alloc] initWithFrame:sv.bounds];
    NSArray* cols = @[@[@"key", @"Calc key", @150], @[@"act", @"Action", @340]];
    for (NSArray* c in cols) {
        NSTableColumn* tc = [[NSTableColumn alloc] initWithIdentifier:c[0]];
        tc.title = c[1]; tc.width = [c[2] doubleValue]; [table addTableColumn:tc];
    }
    table.dataSource = self; table.delegate = self;
    sv.documentView = table; [win.contentView addSubview:sv];

    [self button:@"Remove selected" frame:NSMakeRect(20, 35, 140, 28) action:@selector(removeSel:)];
    [self button:@"Save bindings…" frame:NSMakeRect(170, 35, 130, 28) action:@selector(saveBindings:)];
    [self button:@"Load bindings…" frame:NSMakeRect(305, 35, 130, 28) action:@selector(loadBindings:)];
    hint = [self label:@"Run CALC2KEY on the calculator first. Press [ON] on the calc to exit." frame:NSMakeRect(20, 10, 520, 18)];
    hint.textColor = NSColor.secondaryLabelColor; hint.font = [NSFont systemFontOfSize:11];

    [self loadDefaultBindings];
    [win makeKeyAndOrderFront:nil];

    runThread = new std::thread(runner);
    timer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
    [self tick:nil];
}

- (void)setBindControlsHidden:(BOOL)h {
    actionPop.hidden = h; recordBtn.hidden = h; bindBtn.hidden = h;
    for (NSView* v in win.contentView.subviews)
        if ([v isKindOfClass:NSButton.class] && [((NSButton*)v).title isEqualToString:@"Cancel"]) v.hidden = h;
}

- (void)tick:(NSTimer*)t {
    switch (calcState.load()) {
        case 0: status.stringValue = @"Calculator not detected."; break;
        case 1: status.stringValue = @"Calculator found, but CALC2KEY isn't running on it."; break;
        case 2: status.stringValue = usbOpenError[0] ? [NSString stringWithUTF8String:usbOpenError] : @"Calculator found, but couldn't open it."; break;
        case 3: status.stringValue = @"Connected to calculator."; break;
    }
    BOOL sc = CGPreflightScreenCaptureAccess(), ax = AXIsProcessTrusted();
    perms.stringValue = [NSString stringWithFormat:@"Screen Recording: %@   Accessibility: %@",
                         sc ? @"✓ granted" : @"✗ needed for mirroring", ax ? @"✓ granted" : @"✗ needed for key/mouse binds"];
    if (captureError[0]) perms.stringValue = [NSString stringWithFormat:@"Capture error: %s", captureError];

    float sum = 0; int c = 0;
    for (int i = 0; i < 64; i++) { float v = getFrameTime(NULL, i); if (v > 0) { sum += v; c++; } }
    if (calcState == 3 && c && wantMirror) fps.stringValue = [NSString stringWithFormat:@"Avg frame %.0f ms  (~%.1f fps)", sum / c, 1000.0 * c / sum];
    else fps.stringValue = @"";

    if (binding && bindingKey < 0 && lastCalcKeyUp != 0xFF) {
        bindingKey = lastCalcKeyUp;
        bindLabel.stringValue = [NSString stringWithFormat:@"Binding calc key: %@", calcKeyName(bindingKey)];
        [self setBindControlsHidden:NO];
    }
}

- (void)toggleMirror:(NSButton*)b { wantMirror = (b.state == NSControlStateValueOn); /* applies next time the calc connects */ }
- (void)speedChanged:(NSSlider*)s { mouseSpeed = (int)s.doubleValue; }

- (void)grantPerms:(id)s {
    CGRequestScreenCaptureAccess();
    NSDictionary* o = @{(__bridge NSString*)kAXTrustedCheckOptionPrompt: @YES};
    AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)o);
}

- (void)startBind:(id)s {
    if (calcState != 3) { bindLabel.stringValue = @"Connect the calculator first."; return; }
    lastCalcKeyUp = 0xFF; binding = true; bindingKey = -1; recordedKey = -1;
    bindLabel.stringValue = @"Press a calculator key…";
}

- (void)recordKey:(id)s {
    if (recording) return;
    recording = true; recordBtn.title = @"Press a key…";
    __weak AppDelegate* ws = self;
    keyMonitor = [NSEvent addLocalMonitorForEventsMatchingMask:NSEventMaskKeyDown handler:^NSEvent*(NSEvent* e) {
        AppDelegate* me = ws; if (!me) return e;
        me->recordedKey = e.keyCode;
        me->recordBtn.title = [@"Key: " stringByAppendingString:macKeyName(e.keyCode)];
        [NSEvent removeMonitor:me->keyMonitor]; me->keyMonitor = nil; me->recording = false;
        return nil;
    }];
}

- (void)commitBind:(id)s {
    if (bindingKey < 0) return;
    uint32_t v = 0;
    NSInteger sel = actionPop.indexOfSelectedItem;
    if (sel == 0) { if (recordedKey < 0) { bindLabel.stringValue = @"Click “Record key” and press a key first."; return; } v = KB_ENCODE(recordedKey); }
    else if (sel <= 4) v = MB_MOVE | ((uint32_t)(sel - 1) << 8);
    else if (sel == 5) v = MB_LEFT;
    else v = MB_RIGHT;
    keyBindings[bindingKey] = v;
    [self cancelBind:nil]; [table reloadData]; [self rebuildRows];
}

- (void)cancelBind:(id)s {
    if (keyMonitor) { [NSEvent removeMonitor:keyMonitor]; keyMonitor = nil; }
    recording = false; binding = false; bindingKey = -1; recordedKey = -1;
    recordBtn.title = @"Record key"; bindLabel.stringValue = @"";
    [self setBindControlsHidden:YES];
}

- (void)rebuildRows {
    [rows removeAllObjects];
    for (int i = 0; i < 128; i++) if (keyBindings[i]) [rows addObject:@(i)];
    [table reloadData];
}

- (void)removeSel:(id)s {
    NSInteger r = table.selectedRow; if (r < 0 || r >= (NSInteger)rows.count) return;
    keyBindings[rows[r].intValue] = 0; [self rebuildRows];
}

- (NSURL*)bindingsURL { 
    NSURL* dir = [[NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject URLByAppendingPathComponent:@"CE-ScreenCopy"];
    [NSFileManager.defaultManager createDirectoryAtURL:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return [dir URLByAppendingPathComponent:@"bindings.txt"];
}
- (BOOL)writeBindingsTo:(NSURL*)u {
    NSMutableString* s = [NSMutableString string];
    for (int i = 0; i < 128; i++) if (keyBindings[i]) [s appendFormat:@"%d %u\n", i, keyBindings[i]];
    return [s writeToURL:u atomically:YES encoding:NSUTF8StringEncoding error:nil];
}
- (void)readBindingsFrom:(NSURL*)u {
    NSString* s = [NSString stringWithContentsOfURL:u encoding:NSUTF8StringEncoding error:nil]; if (!s) return;
    memset(keyBindings, 0, sizeof keyBindings);
    for (NSString* line in [s componentsSeparatedByString:@"\n"]) {
        int i; unsigned v;
        if (sscanf(line.UTF8String, "%d %u", &i, &v) == 2 && i >= 0 && i < 128) keyBindings[i] = v;
    }
    [self rebuildRows];
}
- (void)loadDefaultBindings { [self readBindingsFrom:[self bindingsURL]]; }   // auto-restore last session
- (void)saveBindings:(id)s {
    NSSavePanel* p = [NSSavePanel savePanel]; p.nameFieldStringValue = @"calc2key-bindings.txt";
    if ([p runModal] == NSModalResponseOK) [self writeBindingsTo:p.URL];
}
- (void)loadBindings:(id)s {
    NSOpenPanel* p = [NSOpenPanel openPanel];
    if ([p runModal] == NSModalResponseOK) [self readBindingsFrom:p.URL];
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)t { return rows.count; }
- (id)tableView:(NSTableView*)t objectValueForTableColumn:(NSTableColumn*)c row:(NSInteger)r {
    int k = rows[r].intValue;
    return [c.identifier isEqualToString:@"key"] ? calcKeyName(k) : actionName(keyBindings[k]);
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)a { return YES; }
- (void)applicationWillTerminate:(NSNotification*)n {
    [self writeBindingsTo:[self bindingsURL]];
    done = true; stopFlag = 1;
    if (runThread) { runThread->join(); delete runThread; }
}
@end

int main(int argc, const char* argv[])
{
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        AppDelegate* d = [[AppDelegate alloc] init];
        app.delegate = d;
        // minimal menu so Cmd+Q works
        NSMenu* bar = [[NSMenu alloc] init]; NSMenuItem* mi = [[NSMenuItem alloc] init]; [bar addItem:mi];
        NSMenu* m = [[NSMenu alloc] init];
        [m addItemWithTitle:@"Quit CE-ScreenCopy" action:@selector(terminate:) keyEquivalent:@"q"];
        mi.submenu = m; app.mainMenu = bar;
        [app activateIgnoringOtherApps:YES];
        [app run];
    }
    return 0;
}
