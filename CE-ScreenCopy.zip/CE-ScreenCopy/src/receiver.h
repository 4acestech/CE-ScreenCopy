#pragma once
#include <libusb-1.0/libusb.h>
#include <signal.h>

void receiveThread(libusb_device_handle* devHandle, volatile sig_atomic_t* stop);
