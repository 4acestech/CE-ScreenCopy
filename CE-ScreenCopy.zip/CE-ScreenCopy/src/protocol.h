#pragma once
// Shared constants + portable (non-Apple) logic so it can be unit-tested anywhere.
#include <stdint.h>
#include <stddef.h>

#define CALC_WIDTH   320
#define CALC_HEIGHT  240
#define CALC_VID     0x0451
#define CALC_PID_RUN 0xE009   // calc running the CALC2KEY program
#define CALC_PID_OS  0xE008   // calc in normal TI-OS mode
#define EP_OUT       0x02
#define EP_IN        0x81

// Binding encoding (one uint32 per calc key, 0 = unbound)
//   keyboard: 0x10000 | (macKeyCode + 1)      (+1 so keycode 0 = 'A' is representable)
//   mouse   : MB_xxx in low byte, move direction in bits 8..9 (0 up,1 down,2 left,3 right)
#define BIND_KEYBOARD   0x10000u
#define MB_MOVE         1u
#define MB_LEFT         2u
#define MB_RIGHT        8u
#define KB_ENCODE(code) (BIND_KEYBOARD | (uint32_t)((code) + 1))
#define KB_DECODE(b)    ((int)((b) & 0xFFFF) - 1)

// Input backend (implemented in input_mac.mm; stubbed in tests)
void inputKey(int macKeyCode, bool down);
void inputMouseButton(uint32_t mb, bool down);
void inputMouseMove(int dx, int dy);

// Calc report decoding (7 bytes, one bit per key)
extern uint32_t keyBindings[128];
extern int      mouseSpeed;
extern uint8_t  lastCalcKeyUp;
void processReport(const uint8_t* rec /*7 bytes*/);
void applyMouseMotion();   // call every ~10ms
void resetInputState();

// Frame packing: leptonica 32bpp pix (BGRA stream aligned at +1, like upstream) -> USB packet.
// Returns bytes to send (multiple of 64).
#define PACKET_BUF_LEN (512 + CALC_WIDTH * CALC_HEIGHT)
struct Pix;
int  buildPacket(struct Pix* pix, uint8_t* sendBuf /* PACKET_BUF_LEN bytes */);
