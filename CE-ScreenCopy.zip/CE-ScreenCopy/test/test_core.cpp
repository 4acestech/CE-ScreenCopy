#include "../src/protocol.h"
#include "../src/keypad.h"
#include "../src/sender.h"
#include "leptonica/allheaders.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <string>

static std::vector<std::string> log_;
void inputKey(int c, bool d){ log_.push_back("key" + std::to_string(c) + (d?"D":"U")); }
void inputMouseButton(uint32_t m, bool d){ log_.push_back("btn" + std::to_string(m) + (d?"D":"U")); }
void inputMouseMove(int dx, int dy){ log_.push_back("mv" + std::to_string(dx) + "," + std::to_string(dy)); }

static int fails = 0;
#define CHECK(c) do{ if(!(c)){ printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } }while(0)

int main()
{
    CHECK(KB_DECODE(KB_ENCODE(0)) == 0);
    CHECK(KB_DECODE(KB_ENCODE(126)) == 126);

    keyBindings[0x50] = KB_ENCODE(36);          // Enter -> Return
    keyBindings[0x63] = MB_MOVE | (0u << 8);    // Up -> mouse up
    keyBindings[0x00] = MB_LEFT;                // Graph -> left click
    uint8_t r[7] = {0};

    r[5] = 1; processReport(r);
    CHECK(log_.size() == 1 && log_[0] == "key36D");
    processReport(r);
    CHECK(log_.size() == 1);
    r[5] = 0; processReport(r);
    CHECK(log_.size() == 2 && log_[1] == "key36U");
    CHECK(lastCalcKeyUp == 0x50);

    log_.clear();
    r[6] = 1 << 3; processReport(r);
    CHECK(log_.empty());
    mouseSpeed = 7; applyMouseMotion();
    CHECK(log_.size() == 1 && log_[0] == "mv0,-7");
    r[6] = 0; processReport(r); log_.clear(); applyMouseMotion();
    CHECK(log_.empty());

    r[0] = 1; processReport(r);
    CHECK(log_.back() == "btn2D");
    resetInputState();
    CHECK(log_.back() == "btn2U");

    PIX* pix = pixCreateHeader(CALC_WIDTH, CALC_HEIGHT, 32);
    uint8_t* bits = (uint8_t*)malloc(CALC_WIDTH * CALC_HEIGHT * 4 + 1);
    pixSetData(pix, (uint32_t*)bits);
    uint8_t* sendBuf = (uint8_t*)malloc(PACKET_BUF_LEN);
    for (int pass = 0; pass < 3; pass++)
    {
        for (int y = 0; y < CALC_HEIGHT; y++)
            for (int x = 0; x < CALC_WIDTH; x++) {
                uint8_t* p = bits + 1 + (y * CALC_WIDTH + x) * 4;
                if (pass == 0) { p[0]=x; p[1]=y; p[2]=(x+y)/2; p[3]=255; }
                else if (pass == 1) { p[0]=p[1]=p[2]=((x/8+y/8)&1)*255; p[3]=255; }
                else { p[0]=rand(); p[1]=rand(); p[2]=rand(); p[3]=255; }
            }
        int len = buildPacket(pix, sendBuf);
        printf("pass %d: packet %d bytes\n", pass, len);
        CHECK(len % 64 == 0);
        CHECK(len >= 512 && len <= PACKET_BUF_LEN);
    }
    pixDestroy(&pix);
    free(sendBuf);

    printf(fails ? "\n%d FAILED\n" : "\nALL OK\n", fails);
    return fails != 0;
}
