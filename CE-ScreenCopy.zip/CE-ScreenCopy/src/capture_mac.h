#pragma once
#include <stdint.h>

// Screen capture via ScreenCaptureKit, delivered as 320x240 BGRA.
class MacCapture {
public:
    MacCapture();
    ~MacCapture();
    bool start();     // false (and lastError set) if permission/start failed
    void stop();
    // Copies the newest 320x240 BGRA frame into dest. Waits up to waitMs for a *new* frame;
    // if none arrives (static screen) re-delivers the previous one. false only if none ever arrived.
    bool captureNext(uint8_t* dest, int waitMs = 33);
    const char* lastError() const;
    struct Impl;   // public so the ObjC stream delegate can reach it
private:
    Impl* impl;
};
